import Router from "./hashRouter.js";
import Routes from "./routes.js";

window.router = new Router(Routes,"Swipes");